import { Routes } from '@angular/router';
import { CalculadoraPage } from './calculadora/calculadora.page';

// la calculadora es la unica pagina de esta app
export const routes: Routes = [
  { path: '', component: CalculadoraPage },
];
