import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonGrid,
  IonRow,
  IonCol,
  IonButton,
} from '@ionic/angular/standalone';

@Component({
  selector: 'app-calculadora',
  standalone: true,
  templateUrl: './calculadora.page.html',
  styleUrls: ['./calculadora.page.scss'],
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonGrid,
    IonRow,
    IonCol,
    IonButton,
  ],
})
export class CalculadoraPage {
  // aqui guardamos lo que el usuario va escribiendo
  texto = '';

  // se ejecuta cuando el usuario toca un numero o un simbolo
  agregar(valor: string) {
    this.texto = this.texto + valor;
  }

  // borra todo
  borrarTodo() {
    this.texto = '';
  }

  // borra el ultimo caracter
  borrarUltimo() {
    this.texto = this.texto.slice(0, -1);
  }

  // calcula el resultado de la operacion escrita
  calcular() {
    try {
      const resultado = eval(this.texto);
      this.texto = resultado.toString();
    } catch (error) {
      this.texto = 'Error';
    }
  }
}
